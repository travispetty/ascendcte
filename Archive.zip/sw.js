/* AscendCTE demo Service Worker.

   Goal: make repeat navigations instant (matches bfcache feel),
   protect against iOS Safari's aggressive video cache purging, AND
   auto-detect new video uploads to S3 so end users never see stale
   videos even though Travis is silently swapping the underlying
   files in the bucket.

   Strategy:
   - HTML pages: stale-while-revalidate with pathname-normalized cache
     key (strips .html and query string so Pretty URLs and ?restore=1
     navigations all share one cache entry).
   - S3 videos: stale-while-revalidate WITH CONDITIONAL VALIDATION.
     Cache is served instantly; in the background the SW does a
     conditional GET against S3 (If-None-Match / If-Modified-Since)
     using the ETag from the cached response. S3 returns either:
       * 304 Not Modified — no body transferred, ~50ms — current
         cache stays.
       * 200 OK + new body — cache replaced with the new version,
         user sees the update on their next visit.
     This requires the S3 bucket to have a CORS config that allows
     this origin and exposes ETag/Last-Modified headers. Without
     CORS, the cached responses are opaque (no headers visible), so
     conditional GETs aren't possible — the SW falls back to serving
     stale cache forever (the original v1–v4 behavior). The install
     handler tries a CORS fetch first and falls back to no-cors if
     CORS isn't set up, so the site keeps working either way.
   - Everything else (CSS, fonts, etc.): bypass SW, let the browser
     handle it via standard HTTP cache.

   Cache versioning: bump VERSION on every deploy that changes any
   cached file. SW activates the new version, deletes old caches,
   re-fetches everything fresh on next visit. */

const VERSION = 'v42';
const RUNTIME_CACHE = `ascendcte-runtime-${VERSION}`;
const VIDEO_CACHE = `ascendcte-videos-${VERSION}`;

// How often to re-validate a given video URL against S3. 5 minutes
// is short enough for new uploads to propagate fast and long enough
// that we don't hammer S3 with one conditional GET per click. Lives
// in the SW's in-memory scope, so a SW restart resets it — which is
// fine, the worst case is one extra cheap 304 per restart.
const VALIDATE_THROTTLE_MS = 5 * 60 * 1000;
const lastValidated = new Map();

const VIDEO_URLS = [
  'https://demo-ascendcte.s3.us-east-2.amazonaws.com/weldingloop.mp4',
  'https://demo-ascendcte.s3.us-east-2.amazonaws.com/culinaryloop.mp4',
  'https://demo-ascendcte.s3.us-east-2.amazonaws.com/advancedmanufacturingloop.mp4',
  'https://demo-ascendcte.s3.us-east-2.amazonaws.com/healthscienceloop.mp4',
  'https://demo-ascendcte.s3.us-east-2.amazonaws.com/architecturaldraftingdesignloop.mp4',
];

function normalizePath(pathname){
  var p = pathname.replace(/\.html$/, '');
  return p || '/';
}

// Pre-cache helper: try CORS first (so cached response has headers
// for later conditional GETs), fall back to no-cors if S3 isn't
// configured for CORS yet.
function preCacheVideo(cache, url){
  return fetch(url, { mode: 'cors', cache: 'reload' })
    .then(function(resp){
      if(resp.ok && resp.type === 'cors'){
        return cache.put(url, resp);
      }
      throw new Error('not-cors');
    })
    .catch(function(){
      return fetch(url, { mode: 'no-cors', cache: 'reload' })
        .then(function(resp){ return cache.put(url, resp); })
        .catch(function(){});
    });
}

self.addEventListener('install', function(event){
  event.waitUntil(
    caches.open(VIDEO_CACHE).then(function(cache){
      return Promise.all(VIDEO_URLS.map(function(url){ return preCacheVideo(cache, url); }));
    }).then(function(){ return self.skipWaiting(); })
  );
});

self.addEventListener('activate', function(event){
  event.waitUntil(
    caches.keys().then(function(keys){
      return Promise.all(keys
        .filter(function(k){ return !k.endsWith(VERSION); })
        .map(function(k){ return caches.delete(k); })
      );
    }).then(function(){ return self.clients.claim(); })
  );
});

// Background revalidation. Reads ETag/Last-Modified off the cached
// response (only readable if cached as CORS, not opaque). Issues a
// conditional GET — S3 returns 304 if unchanged, 200 + new body if
// Travis has uploaded a new version. On 200, cache is replaced and
// the user sees the new video on their next request.
function revalidateVideo(cache, request, cached){
  var url = request.url;
  var prev = lastValidated.get(url);
  if(prev && (Date.now() - prev) < VALIDATE_THROTTLE_MS) return;
  lastValidated.set(url, Date.now());

  var etag = cached.headers.get('ETag');
  var lastMod = cached.headers.get('Last-Modified');

  if(etag || lastMod){
    // We have CORS headers — do a conditional GET. Cheap when
    // unchanged (304, no body), automatic when changed (200, new body).
    var headers = {};
    if(etag) headers['If-None-Match'] = etag;
    if(lastMod) headers['If-Modified-Since'] = lastMod;

    fetch(url, { method: 'GET', mode: 'cors', headers: headers })
      .then(function(resp){
        if(resp.status === 200 && resp.ok && resp.type === 'cors'){
          // New version detected — replace cache.
          cache.put(request, resp);
        }
        // 304: cache is current, nothing to do.
      })
      .catch(function(){ /* network/CORS error, leave cache as-is */ });
  } else {
    // Opaque cache (no readable headers). Try to upgrade to a CORS
    // response so future revalidations can use conditional GETs.
    // If this fails (because S3 CORS isn't configured), we silently
    // give up — the throttle will keep us from retrying constantly,
    // and the site keeps working with stale-forever caching.
    fetch(url, { mode: 'cors' })
      .then(function(resp){
        if(resp.ok && resp.type === 'cors'){
          cache.put(request, resp);
        }
      })
      .catch(function(){});
  }
}

self.addEventListener('fetch', function(event){
  if(event.request.method !== 'GET') return;

  var url = new URL(event.request.url);

  // S3 videos: stale-while-revalidate with conditional validation.
  if(url.pathname.endsWith('.mp4')){
    event.respondWith(
      caches.open(VIDEO_CACHE).then(function(cache){
        return cache.match(event.request).then(function(cached){
          if(cached){
            // Only validate on non-range requests. Video elements
            // make many range requests per playback (one per chunk);
            // validating each one would hammer S3 for no reason.
            // The initial non-range request triggers validation once.
            if(!event.request.headers.has('range')){
              revalidateVideo(cache, event.request, cached);
            }
            return cached;
          }
          // Cache miss: fetch and cache.
          return fetch(event.request, { mode: 'no-cors' }).then(function(resp){
            var respClone = resp.clone();
            cache.put(event.request, respClone);
            return resp;
          });
        });
      })
    );
    return;
  }

  // Same-origin HTML documents: stale-while-revalidate with
  // pathname-normalized cache key.
  if(url.origin === self.location.origin &&
     (event.request.destination === 'document' || event.request.mode === 'navigate')){
    var normalKey = url.origin + normalizePath(url.pathname);
    event.respondWith(
      caches.open(RUNTIME_CACHE).then(function(cache){
        return cache.match(normalKey).then(function(cached){
          var fetchPromise = fetch(event.request).then(function(resp){
            if(resp && resp.ok && resp.type === 'basic'){
              cache.put(normalKey, resp.clone());
            }
            return resp;
          }).catch(function(){ return cached; });
          return cached || fetchPromise;
        });
      })
    );
    return;
  }
});
